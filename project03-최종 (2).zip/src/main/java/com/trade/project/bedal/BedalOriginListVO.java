package com.trade.project.bedal;

public class BedalOriginListVO {
	
	String bedal_list_id;
	String product_id;
	String user_id;
	String payment_id;
	int bedal_list_status;
	String bedal_id;
	
	public String getBedal_id() {
		return bedal_id;
	}
	public void setBedal_id(String bedal_id) {
		this.bedal_id = bedal_id;
	}
	public String getBedal_list_id() {
		return bedal_list_id;
	}
	public void setBedal_list_id(String bedal_list_id) {
		this.bedal_list_id = bedal_list_id;
	}
	public String getProduct_id() {
		return product_id;
	}
	public void setProduct_id(String product_id) {
		this.product_id = product_id;
	}
	public String getUser_id() {
		return user_id;
	}
	public void setUser_id(String user_id) {
		this.user_id = user_id;
	}
	public String getPayment_id() {
		return payment_id;
	}
	public void setPayment_id(String payment_id) {
		this.payment_id = payment_id;
	}
	public int getBedal_list_status() {
		return bedal_list_status;
	}
	public void setBedal_list_status(int bedal_list_status) {
		this.bedal_list_status = bedal_list_status;
	}
	
	

}

