package com.trade.project.algolism.qa;

public class AlgolismVO {
	int qa_no;
	String user_id;
	String user_name;
	String qa_title;
	int user_age;
	int qa_count;
	int qa_age;
	String admin_answer;
	
	
	public String getAdmin_answer() {
		return admin_answer;
	}
	public void setAdmin_answer(String admin_answer) {
		this.admin_answer = admin_answer;
	}
	public int getQa_no() {
		return qa_no;
	}
	public void setQa_no(int qa_no) {
		this.qa_no = qa_no;
	}
	public String getUser_id() {
		return user_id;
	}
	public void setUser_id(String user_id) {
		this.user_id = user_id;
	}
	public String getUser_name() {
		return user_name;
	}
	public void setUser_name(String user_name) {
		this.user_name = user_name;
	}
	public String getQa_title() {
		return qa_title;
	}
	public void setQa_title(String qa_title) {
		this.qa_title = qa_title;
	}
	public int getUser_age() {
		return user_age;
	}
	public void setUser_age(int user_age) {
		this.user_age = user_age;
	}
	public int getQa_count() {
		return qa_count;
	}
	public void setQa_count(int qa_count) {
		this.qa_count = qa_count;
	}
	public int getQa_age() {
		return qa_age;
	}
	public void setQa_age(int qa_age) {
		this.qa_age = qa_age;
	}
	
	
	
	
}
