package com.trade.project.user;

public class UserReviewVO {
	private String user_id; // 상품 아이디
	private int review1_count; // 리뷰 항목1
	private int review2_count; // 리뷰 항목2
	private int review3_count; // 리뷰 항목3
	private int review4_count; // 리뷰 항목4
	private int review5_count; // 리뷰 항목5
	private int review6_count; // 리뷰 항목6
	private int review7_count; // 리뷰 항목7
	private int review8_count; // 리뷰 항목8
	
	public String getUser_id() {
		return user_id;
	}
	public void setUser_id(String user_id) {
		this.user_id = user_id;
	}
	public int getReview1_count() {
		return review1_count;
	}
	public void setReview1_count(int review1_count) {
		this.review1_count = review1_count;
	}
	public int getReview2_count() {
		return review2_count;
	}
	public void setReview2_count(int review2_count) {
		this.review2_count = review2_count;
	}
	public int getReview3_count() {
		return review3_count;
	}
	public void setReview3_count(int review3_count) {
		this.review3_count = review3_count;
	}
	public int getReview4_count() {
		return review4_count;
	}
	public void setReview4_count(int review4_count) {
		this.review4_count = review4_count;
	}
	public int getReview5_count() {
		return review5_count;
	}
	public void setReview5_count(int review5_count) {
		this.review5_count = review5_count;
	}
	public int getReview6_count() {
		return review6_count;
	}
	public void setReview6_count(int review6_count) {
		this.review6_count = review6_count;
	}
	public int getReview7_count() {
		return review7_count;
	}
	public void setReview7_count(int review7_count) {
		this.review7_count = review7_count;
	}
	public int getReview8_count() {
		return review8_count;
	}
	public void setReview8_count(int review8_count) {
		this.review8_count = review8_count;
	}
	
	
	
}
